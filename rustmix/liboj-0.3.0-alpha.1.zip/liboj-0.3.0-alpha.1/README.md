# LibOJ

[![pipeline status](https://gitlab.com/hr567/liboj/badges/master/pipeline.svg)](https://gitlab.com/hr567/liboj/commits/master)

A high performance framework for building online judge system.
