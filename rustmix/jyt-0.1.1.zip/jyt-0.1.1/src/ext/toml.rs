#![allow(clippy::needless_question_mark)]
crate::ext::macros::impl_serde!(toml, to_string);
