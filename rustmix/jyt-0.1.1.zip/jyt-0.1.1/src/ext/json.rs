#![allow(clippy::needless_question_mark)]
crate::ext::macros::impl_serde!(serde_json, to_string_pretty);
