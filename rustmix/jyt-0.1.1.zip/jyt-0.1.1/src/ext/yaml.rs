#![allow(clippy::needless_question_mark)]
crate::ext::macros::impl_serde!(serde_yaml, to_string);
